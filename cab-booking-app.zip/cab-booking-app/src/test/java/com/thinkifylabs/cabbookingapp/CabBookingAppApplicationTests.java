package com.thinkifylabs.cabbookingapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CabBookingAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
